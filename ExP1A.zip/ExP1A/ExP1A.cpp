/*
  Matricula:A01282875
  Nombre:Diego Fernando Montaño Pérez
*/

#include <iostream>
#include <vector>

using namespace std;

bool iguales(vector<int> &d, int k){
    int i = 0;
    if(d.size() == 0 || d.size() == 1){
        return false;
    }
    while(i < d.size()){
        if(d[i] == d[i+k]){
            return true;
        }
        i++;
    }
	return false;
}

int main(){
	int n, k;
	cin >> n >> k;
	vector<int> datos(n);
	for (int i=0; i<n; i++){
		cin>>datos[i];
	}
  cout << (iguales(datos, k)? "YES" : "NO") <<endl;
}

/*
Ejemplo 1
4 3
1 2 3 1

Ejemplo 2
4 1
1 0 1 1

Ejmplo 3
6 2
1 2 3 1 2 3

*/
